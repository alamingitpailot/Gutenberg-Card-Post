<?php
/**
 * Plugin Name: Post Cards
 * Description: Self hosted plugin.
 * Version: 1.0.0
 * Author: bPlugins LLC
 * Author URI: http://bplugins.com
 * License: GPLv3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain: post-cards
 */

// ABS PATH
if ( !defined( 'ABSPATH' ) ) { exit; }

// Constant
define( 'PCB_PLUGIN_VERSION', 'localhost' === $_SERVER['HTTP_HOST'] ? time() : '1.0.0' );
define( 'PCB_ASSETS_DIR', plugin_dir_url( __FILE__ ) . 'assets/' );

// Block Directory
class PCBPostCards{
	function __construct(){
		add_action( 'init', [$this, 'onInit'] );
	}

	function onInit() {
		wp_register_style( 'pcb-post-cards-editor-style', plugins_url( 'dist/editor.css', __FILE__ ), [ 'wp-edit-blocks' ], PCB_PLUGIN_VERSION ); // Backend Style
		wp_register_style( 'pcb-post-cards-style', plugins_url( 'dist/style.css', __FILE__ ), [ 'wp-editor' ], PCB_PLUGIN_VERSION ); // Frontend Style

		register_block_type( __DIR__, [
			'editor_style'		=> 'pcb-post-cards-editor-style',
			'style'				=> 'pcb-post-cards-style',
			'render_callback'	=> [$this, 'render']
		] ); // Register Block

		wp_set_script_translations( 'pcb-post-cards-editor-script', 'post-cards', plugin_dir_path( __FILE__ ) . 'languages' ); // Translate
	}

	function render( $attributes ){
		extract( $attributes );

		$className = $className ?? '';
		$pcbBlockClassName = 'wp-block-pcb-post-cards ' . $className . ' align' . $align;

		ob_start(); ?>
		<div class='<?php echo esc_attr( $pcbBlockClassName ); ?>' id='pcbPostCards-<?php echo esc_attr( $cId ) ?>' data-attributes='<?php echo esc_attr( wp_json_encode( $attributes ) ); ?>'></div>

		<?php return ob_get_clean();
	} // Render
}
new PCBPostCards();